from django.shortcuts import render
import numpy as np
import pandas as pd
import math as math

# Create your views here.
def search1(request):
    return render(request,'search1.html')

p1 = "주택도시기금 디딤돌 대출"
p2 = "주택도시기금 신혼부부전용 구입자금"
p3 = "오피스텔 구입자금"
p4 = "한국주택금융공사 보금자리론"
p5 = "한국주택금융공사 디딤돌대출"
p6 = "신혼부부전용 전세자금"
p7 = "버팀목전세자금"
p8 = "중소기업취업청년 전월세 대출"
p9 = "청년전용 보증부월세대출"
p10 = "청년전용 버팀목전세자금(일반)"
p11 = "주거안정월세대출(일반)"
p12 = "주거안정월세대출(우대/취준생)"
p13 = "주거안정월세대출(우대/사회초년생)"
p14 = "청년전용 버팀목전세자금(신혼/다자녀/2자녀가구)"


def search_result(request):
    q1 = request.GET['question1']
    q2 = request.GET['question2']
    q3 = request.GET['question3']
    q4 = request.GET['question4']
    q5 = request.GET['question5']
    q6 = request.GET['question6']
    q7 = request.GET['question7']

    def pro1():

        cond = (int(q1)==1) or (int(q1)==2 and int(q2)>=30) or (int(q2)>=30 and int(q3)==1) or (int(q3) in [2,3])
        if cond and int(q5)<=6000 and int(q6)==2 and int(q7)==1 :
            return p1
        else:
            return ''

    def pro2():

        cond = (int(q1)==1) or (int(q1)==2 and int(q2)>=30)
        if cond and int(q3)==2 and int(q5)<=7000 and int(q6)==2 and int(q7)==1 :
            return p2
        else:
            return ''
    
    def pro3():

        cond = (int(q1)==1) or (int(q1)==2 and int(q2)>=30) or (int(q2)>=30 and int(q3)==1) or (int(q3) in [2,3])
        if cond and int(q5)<=6000 and int(q6)==2 and int(q7)==1 :
            return p3
        else:
            return ''

    def pro4():
        
        if (int(q1) in [1,2,3,4]) and (int(q2) >= 19 and int(q3) in [1,2]) and (int(q5)<=8500) and (int(q6) in [1,2,3]) and (int(q7)==1):
            return p4
        else:
            return ''

    def pro5():

        if int(q1) in [1,2] and int(q2) >= 19 and int(q3)==2 and int(q5)<=6000 and int(q6) in [1,2,3] and int(q7)==1:
            if int(q1) == 2 and int(q2) < 30 :
                return ""
            else:
                return p5
        else:
            return ""
        
    def pro6():

        if int(q1)==1 and int(q2) >= 19 and int(q3)==2 and int(q5)<=6000 and int(q6)==1 and int(q7)==2:
            return p6
        else:
            return ''

    def pro7():

        if int(q1)==1 and int(q2) >=19 and int(q3) in [1,2,3] and int(q5)<=5000 and int(q6)==1 and int(q7)==2:
            return p7
        else:
            return ''

    def pro8():

        if int(q1) in [1,2] and int(q2) in range(19,35) and int(q3) in [1,2,3] and int(q5)<=5000 and int(q6)==1 and int(q7)==2:
            return p8
        else:
            return ''

    def pro9():

        if int(q1) in [1,2] and int(q2)>=19 and int(q3) in [1,2,3] and int(q5)<=5000 and int(q6)==1 and int(q7)==2:
            return p9
        else:
            return ''

    def pro10():
        if int(q1) in [1,2] and int(q2) in range(19,35) and int(q3) in [1,2,3] and int(q4) in [1,2,3,4] and int(q5)<=5000 and int(q6)==1 and int(q7)==2:
            return p10
        else:
            return ''


    def pro11():
    
        if int(q1) in [1,2] and int(q2)>=19 and int(q3) in [1,2,3] and int(q4) in [1,2,3,4] and int(q5)<=5000 and int(q6)==1 and int(q7)==2:
            return p11
        else:
            return ''

    def pro12():
        
        if int(q1) in [1,2] and int(q2) in range(19,36) and int(q3)==1 and int(q4)==1 and int(q5)==0 and int(q6)==1 and int(q7)==2:
            return p12
        else:
            return ''

    def pro13():
        
        if int(q1) in [1,2] and int(q2) in range(19,36) and int(q3) in [1,2,3] and int(q4) in [1,2,3,4] and int(q5)<=4000 and int(q6)==1 and int(q7)==2:
            return p13
        else:
            return ''

    def pro14():
        
        if int(q1)==1 and int(q2) in range(19,35) and int(q3) in [2,3] and int(q4) in [3,4] and int(q5)<=6000 and int(q6)==1 and int(q7)==2:
            return p14
        else:
            return ''

    result = [pro1(), pro2(), pro3(), pro4(), pro5(), pro6(), pro7(), pro8(), pro9(), pro10(), pro11(), pro12(), pro13(), pro14()]


    return render(request,'result.html',{
                    'q1':q1, 
                    'q2':q2,
                    'q3':q3,
                    'q4':q4,
                    'q5':q5,
                    'q6':q6,
                    'q7':q7,
                    'pro1':pro1(),
                    'pro2':pro2(),
                    'pro3':pro3(),
                    'pro4':pro4(),
                    'pro5':pro5(),
                    'pro6':pro6(),
                    'pro7':pro7(),
                    'pro8':pro8(),
                    'pro9':pro9(),
                    'pro10':pro10(),
                    'pro11':pro11(),
                    'pro12':pro12(),
                    'pro13':pro13(),
                    'pro14':pro14(),
                    'result':result,
                    })



def calculator(request):
    return render(request,'calculator.html')

    
def calcresult(request):
    cq1 = request.GET['calcquestion1']
    cq2 = request.GET['calcquestion2']
    cq3 = request.GET['calcquestion3']
    cq4 = request.GET['calcquestion4']
    # cq2_1=float(cq2_1)/12.0# 연이율을 월 cq2_1로 변환
    cq2_1 = float(cq2)/12.0
    cq1 = int(cq1)
    cq3 = int(cq3)
    
    if int(cq4)==1: #원리금 균등상환
        
        # X : 월 원리금균등상환금액
        X = (cq1 * cq2_1 * ((1 + cq2_1)**cq3)) / (((1 + cq2_1)**cq3) - 1)
        interest1 = pd.DataFrame({'대출경과월' : np.arange(1, cq3+1, 1)}) # 대출경과월 셋팅 1 ~ 36 개월
        interest1["원리금균등상환액"] = X # 위에서 산출한 월 원리금균등상환금액 삽입

        # 매월 원금납입액, 이자납입액, 이자납입비율 산출
        for i in range(interest1["대출경과월"].size) :
            interest1.loc[i, "원금납입액"] = interest1.loc[i,"원리금균등상환액"] / ((1 + cq2_1)**(cq3 - i))
            interest1.loc[i, "이자납입액"] = interest1.loc[i,"원리금균등상환액"] - interest1.loc[i, "원금납입액"]
            interest1.loc[i, "이자납입율(%)"] = round(interest1.loc[i, "이자납입액"] / interest1.loc[i,"원리금균등상환액"] * 100, 2)

        
        print(interest1)
        # Table1 = interest1.to_html(justify='center')
        # interest1 = interest1.to_html()
        return interest1    

# if response.get('X-Frame-Options') is not None:
# AttributeError: 'str' object has no attribute 'get'
# 여기서 에러남:  html로 아예 받아서 새 페이지 열까..? print는 잘 됨 넘기기가 안될뿐,,

    elif int(cq4)==2: #원금균등상환

        # 대출경과월 세팅
        interest2 = pd.DataFrame({"대출경과월":range(cq3)}) + 1

        # 매월 납입하는 cq1 계산
        interest2["원금납입액"] = round(cq1 / cq3)

        # 마지막 납입월 보정 (1200만원 / 36의 값이 무한소수로 표현되므로 마지막 납입금액 보정 작업 수행
        interest2.loc[cq3-1,"원금납입액"] =math.floor(cq1/cq3)

        # 대출 경과월에 따른 대출잔액, 월이자납입금액 계산
        for i in range(interest2["대출경과월"].size) :
            if i == 0 :
                interest2.loc[i, "대출잔액"] = round(cq1 - interest2.loc[i,"원금납입액"])
            else :
                interest2.loc[i, "대출잔액"] = round(interest2.loc[i-1, "대출잔액"] - interest2.loc[i, "원금납입액"]) 
                interest2.loc[i, "월이자납입금액"] = interest2.loc[i, "대출잔액"] * float(cq2)
            
                
        # 대출상환표 출력
        return interest2

        
    elif int(cq4)==3: #만기일시상환
        pass
    else:
        return ""

    
    return render(request,'calcresult.html',{
                    'cq1':cq1,
                    'cq2':cq2_1, 
                    'cq3':cq3,
                    'cq4':cq4,
                    'interest1':interest1
                    })