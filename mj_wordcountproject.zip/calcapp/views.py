from django.shortcuts import render

# Create your views here.
def hello(request):
    return render(request,'hello.html')

def wordcount(request):
    return render(request,'wordcount.html')

def result(request):
    text = request.GET['fulltext']
    text = text.split()

    text_dict={}
    for word in text:
        if word not in text_dict:
            text_dict[word] = 0
    for word in text:
        text_dict[word] += 1

    total_sum = sum(list(text_dict.values()))

    return render(request,'result.html',{'mytext':text_dict, 'total':total_sum})